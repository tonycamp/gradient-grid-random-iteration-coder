#include "Gradient Coder v05.bmx.console.release.win32.x64.h"
struct BBString_1{BBClass_String* clas;BBULONG hash;int length;BBChar buf[1];};
struct BBString_7{BBClass_String* clas;BBULONG hash;int length;BBChar buf[7];};
struct BBString_9{BBClass_String* clas;BBULONG hash;int length;BBChar buf[9];};
struct BBString_8{BBClass_String* clas;BBULONG hash;int length;BBChar buf[8];};
struct BBString_11{BBClass_String* clas;BBULONG hash;int length;BBChar buf[11];};
struct BBString_12{BBClass_String* clas;BBULONG hash;int length;BBChar buf[12];};
struct BBString_3{BBClass_String* clas;BBULONG hash;int length;BBChar buf[3];};
struct BBString_4{BBClass_String* clas;BBULONG hash;int length;BBChar buf[4];};
struct BBString_10{BBClass_String* clas;BBULONG hash;int length;BBChar buf[10];};
struct BBString_17{BBClass_String* clas;BBULONG hash;int length;BBChar buf[17];};
struct BBString_93{BBClass_String* clas;BBULONG hash;int length;BBChar buf[93];};
struct BBString_36{BBClass_String* clas;BBULONG hash;int length;BBChar buf[36];};
struct BBString_27{BBClass_String* clas;BBULONG hash;int length;BBChar buf[27];};
struct BBString_26{BBClass_String* clas;BBULONG hash;int length;BBChar buf[26];};
struct BBString_40{BBClass_String* clas;BBULONG hash;int length;BBChar buf[40];};
struct BBString_35{BBClass_String* clas;BBULONG hash;int length;BBChar buf[35];};
struct BBString_54{BBClass_String* clas;BBULONG hash;int length;BBChar buf[54];};
struct BBString_24{BBClass_String* clas;BBULONG hash;int length;BBChar buf[24];};
struct BBString_2{BBClass_String* clas;BBULONG hash;int length;BBChar buf[2];};
static struct BBString_1 _s35={
	&bbStringClass,
	0x718db1f80b30d14b,
	1,
	{10}
};
static struct BBString_1 _s34={
	&bbStringClass,
	0x7482aa09ce5ccee4,
	1,
	{13}
};
static struct BBString_7 _s28={
	&bbStringClass,
	0xa01e10964eaa946b,
	7,
	{32,32,32,32,32,32,32}
};
static struct BBString_9 _s24={
	&bbStringClass,
	0xa76a07652ee9d911,
	9,
	{32,71,114,105,100,32,120,121,61}
};
static struct BBString_7 _s27={
	&bbStringClass,
	0xcf6f5cb824659d69,
	7,
	{32,83,73,90,69,61,32}
};
static struct BBString_8 _s29={
	&bbStringClass,
	0x95e90c10fc02ea13,
	8,
	{32,100,97,121,115,32,58,32}
};
static struct BBString_11 _s26={
	&bbStringClass,
	0x2ee4f11dcbb45786,
	11,
	{32,116,105,109,101,32,76,101,102,116,58}
};
static struct BBString_12 _s25={
	&bbStringClass,
	0xfe45e77c3c1c1f26,
	12,
	{32,118,97,108,117,101,32,65,100,118,46,61}
};
static struct BBString_3 _s23={
	&bbStringClass,
	0x7bb6bceb84e9159f,
	3,
	{32,121,61}
};
static struct BBString_4 _s19={
	&bbStringClass,
	0x572056b1eea3b140,
	4,
	{46,100,97,116}
};
static struct BBString_10 _s20={
	&bbStringClass,
	0x5bcbec62376c25ee,
	10,
	{46,100,97,116,46,112,97,113,56,111}
};
static struct BBString_17 _s21={
	&bbStringClass,
	0xfe4583b5c1f7c001,
	17,
	{46,111,114,105,103,105,110,97,108,46,100,97,116,46,112,110,103
}
};
static struct BBString_1 _s30={
	&bbStringClass,
	0xf1246dec78a245bd,
	1,
	{48}
};
static struct BBString_1 _s31={
	&bbStringClass,
	0xa923075edaefdbcb,
	1,
	{58}
};
static struct BBString_93 _s11={
	&bbStringClass,
	0xd1fb367b3ce85d3a,
	93,
	{66,77,80,32,79,82,32,84,71,65,32,79,82,32,80,78,71
	,32,79,82,32,74,80,71,32,50,32,69,120,112,101,114,105
	,109,101,110,116,97,108,32,86,101,114,115,105,111,110,32,84
	,111,32,68,65,84,32,98,121,32,84,111,110,121,32,67,97
	,109,112,32,44,32,65,110,116,111,110,105,111,32,67,97,109
	,112,97,110,105,99,111,32,44,32,116,111,105}
};
static struct BBString_36 _s32={
	&bbStringClass,
	0xb422ad9b26496973,
	36,
	{67,79,77,80,82,69,83,83,73,79,78,32,69,78,68,69,68
	,32,58,32,69,108,97,112,115,101,100,32,84,105,109,101,32
	,32,61,32}
};
static struct BBString_27 _s33={
	&bbStringClass,
	0x9e889bcfe9ab09b7,
	27,
	{73,109,97,103,101,32,115,97,118,101,100,32,97,115,32,111,114
	,105,103,105,110,97,108,46,112,110,103}
};
static struct BBString_26 _s12={
	&bbStringClass,
	0x66d15a138c4c5f34,
	26,
	{78,97,109,101,32,111,102,32,70,105,108,101,32,84,111,32,67
	,111,109,112,114,101,115,115,32,58}
};
static struct BBString_40 _s17={
	&bbStringClass,
	0x7cca0ffa9c867f02,
	40,
	{78,117,109,98,101,114,32,111,102,32,85,32,68,105,118,105,115
	,111,114,32,40,32,49,32,47,32,50,32,47,32,52,32,47
	,32,56,32,41,32,58,32}
};
static struct BBString_40 _s18={
	&bbStringClass,
	0x664f20187950a587,
	40,
	{78,117,109,98,101,114,32,111,102,32,86,32,68,105,118,105,115
	,111,114,32,40,32,49,32,47,32,50,32,47,32,52,32,47
	,32,56,32,41,32,58,32}
};
static struct BBString_36 _s16={
	&bbStringClass,
	0x74ee3998a9444913,
	36,
	{78,117,109,98,101,114,32,111,102,32,89,32,68,105,118,105,115
	,111,114,32,40,32,49,32,47,32,50,32,47,32,52,32,41
	,32,58,32}
};
static struct BBString_35 _s13={
	&bbStringClass,
	0xc21dcb20cfb8ec5,
	35,
	{78,117,109,98,101,114,32,111,102,32,105,116,101,114,97,116,105
	,111,110,115,32,40,48,45,55,48,48,48,48,48,48,41,32
	,58,32}
};
static struct BBString_54 _s15={
	&bbStringClass,
	0x32cc957af4406354,
	54,
	{78,117,109,98,101,114,32,111,102,32,115,113,117,97,114,101,32
	,103,114,105,100,32,40,32,50,32,47,32,51,32,47,32,52
	,32,47,32,53,32,47,32,54,32,47,32,55,32,47,32,56
	,32,41,32,58,32}
};
static struct BBString_24 _s14={
	&bbStringClass,
	0x6e6b6da37dd2aeef,
	24,
	{82,97,110,103,101,32,78,117,109,98,101,114,32,40,49,54,45
	,49,50,56,41,32,58,32}
};
static struct BBString_2 _s22={
	&bbStringClass,
	0xce4c4d5aed8fa047,
	2,
	{120,61}
};
BBINT _m_Gradient_Coder_v05_largura=0;
BBINT _m_Gradient_Coder_v05_altura=0;
BBINT _m_Gradient_Coder_v05_chunk=0;
struct brl_pixmap_TPixmap_obj* _m_Gradient_Coder_v05_imagemap=(struct brl_pixmap_TPixmap_obj*)((struct brl_pixmap_TPixmap_obj*)&bbNullObject);
BBSTRING _m_Gradient_Coder_v05_Stringdata=((BBString*)&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_Stringiter=((BBString*)&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_Stringadverage=((BBString*)&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_Stringrange=((BBString*)&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_Stringaccuracy=((BBString*)&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_stringtolerance=((BBString*)&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_Stringnoise=((BBString*)&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_Stringyd=((BBString*)&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_Stringud=((BBString*)&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_Stringvd=((BBString*)&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_filestringoutdat=(&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_filestringoutdatpaq8o=(&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_filestringinbmp=(&bbEmptyString);
BBSTRING _m_Gradient_Coder_v05_filestringoutdatpng=(&bbEmptyString);
struct brl_stream_TStream_obj* _m_Gradient_Coder_v05_file001=(struct brl_stream_TStream_obj*)((struct brl_stream_TStream_obj*)&bbNullObject);
BBINT _m_Gradient_Coder_v05_num3=0;
BBSTRING _m_Gradient_Coder_v05_stringElapsedTime=((BBString*)&bbEmptyString);
BBINT _m_Gradient_Coder_v05_timespend=0;
BBFLOAT _m_Gradient_Coder_v05_elapsedtime=.00000000f;
BBFLOAT _m_Gradient_Coder_v05_begintime=.00000000f;
BBDOUBLE _m_Gradient_Coder_v05_begintime2=.0000000000000000;
BBINT _m_Gradient_Coder_v05_iterations=0;
BBINT _m_Gradient_Coder_v05_adverage=0;
BBINT _m_Gradient_Coder_v05_gridx=0;
BBINT _m_Gradient_Coder_v05_gridy=0;
BBINT _m_Gradient_Coder_v05_divisory=0;
BBINT _m_Gradient_Coder_v05_divisoru=0;
BBINT _m_Gradient_Coder_v05_divisorv=0;
BBINT _m_Gradient_Coder_v05_range=0;
BBINT _m_Gradient_Coder_v05_accuracy=0;
BBINT _m_Gradient_Coder_v05_tolerance=0;
BBINT _m_Gradient_Coder_v05_noise=0;
BBARRAY _m_Gradient_Coder_v05_valuered=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuegreen=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueblue=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuered2=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuegreen2=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueblue2=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuey=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueu=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuev=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuey2=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueu2=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuev2=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuey3=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueu3=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuev3=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuesya=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuesua=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuesva=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuesyaf=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuesuaf=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuesvaf=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_tabelarandomy=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_tabelarandomu=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_tabelarandomv=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuesy=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuesu=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuesv=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueyf=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueuf=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuevf=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueyf2=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueuf2=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuevf2=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueyf3=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueuf3=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuevf3=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueyf4=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valueuf4=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_valuevf4=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_tabelafinaly=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_tabelafinalu=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_tabelafinalv=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_errory=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_erroru=(&bbEmptyArray);
BBARRAY _m_Gradient_Coder_v05_errorv=(&bbEmptyArray);
BBINT _m_Gradient_Coder_v05_valor1=0;
BBINT _m_Gradient_Coder_v05_valor2=0;
BBINT _m_Gradient_Coder_v05_valor3=0;
BBINT _m_Gradient_Coder_v05_valor4=0;
BBINT _m_Gradient_Coder_v05_valor=0;
BBINT _m_Gradient_Coder_v05_g=0;
BBINT _m_Gradient_Coder_v05_x=0;
BBINT _m_Gradient_Coder_v05_x1=0;
BBINT _m_Gradient_Coder_v05_y=0;
BBINT _m_Gradient_Coder_v05_y1=0;
BBINT _m_Gradient_Coder_v05_f=0;
BBINT _m_Gradient_Coder_v05_randomiter=0;
BBINT _m_Gradient_Coder_v05_maxnum=0;
BBDOUBLE _m_Gradient_Coder_v05_maxnumfinal=.0000000000000000;
BBINT _m_Gradient_Coder_v05_num=0;
BBINT _m_Gradient_Coder_v05_finaliter=0;
BBDOUBLE _m_Gradient_Coder_v05_actualtime=.0000000000000000;
BBDOUBLE _m_Gradient_Coder_v05_buffertime=.0000000000000000;
BBDOUBLE _m_Gradient_Coder_v05_timeleft=.0000000000000000;
BBINT _m_Gradient_Coder_v05_diff=0;
BBINT _m_Gradient_Coder_v05_trys=0;
BBINT _m_Gradient_Coder_v05_bita1=0;
BBINT _m_Gradient_Coder_v05_insert=0;
BBDOUBLE _m_Gradient_Coder_v05_insertfinal=.0000000000000000;
BBINT _m_Gradient_Coder_v05_insertiter=0;
BBDOUBLE _m_Gradient_Coder_v05_maxinsertfinal=.0000000000000000;
BBDOUBLE _m_Gradient_Coder_v05_maxinsertiter=.0000000000000000;
BBDOUBLE _m_Gradient_Coder_v05_mediafinal=.0000000000000000;
BBDOUBLE _m_Gradient_Coder_v05_multiply=.0000000000000000;
BBDOUBLE _m_Gradient_Coder_v05_size=.0000000000000000;
BBINT _m_Gradient_Coder_v05_createrandoms(){
	random_core_SeedRnd(0);
	BBINT bbt_=_m_Gradient_Coder_v05_iterations;
	for(_m_Gradient_Coder_v05_f=0;(_m_Gradient_Coder_v05_f<=bbt_);_m_Gradient_Coder_v05_f=(_m_Gradient_Coder_v05_f+1)){
		BBINT bbt_2=_m_Gradient_Coder_v05_gridy;
		for(_m_Gradient_Coder_v05_y=0;(_m_Gradient_Coder_v05_y<=bbt_2);_m_Gradient_Coder_v05_y=(_m_Gradient_Coder_v05_y+1)){
			BBINT bbt_3=_m_Gradient_Coder_v05_gridx;
			for(_m_Gradient_Coder_v05_x=0;(_m_Gradient_Coder_v05_x<=bbt_3);_m_Gradient_Coder_v05_x=(_m_Gradient_Coder_v05_x+1)){
				BBUINT* bbt_4=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomy)->scales + 1;
				((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomy,1))[(*(bbt_4)) * ((BBUINT)_m_Gradient_Coder_v05_f) + (*(bbt_4+1)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=random_core_Rand(_m_Gradient_Coder_v05_range,1);
				BBUINT* bbt_5=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomy)->scales + 1;
				BBUINT* bbt_6=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomy)->scales + 1;
				((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomy,1))[(*(bbt_6)) * ((BBUINT)_m_Gradient_Coder_v05_f) + (*(bbt_6+1)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomy,1))[(*(bbt_5)) * ((BBUINT)_m_Gradient_Coder_v05_f) + (*(bbt_5+1)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]-(_m_Gradient_Coder_v05_range/2));
				BBUINT* bbt_7=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomu)->scales + 1;
				((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomu,1))[(*(bbt_7)) * ((BBUINT)_m_Gradient_Coder_v05_f) + (*(bbt_7+1)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=random_core_Rand(_m_Gradient_Coder_v05_range,1);
				BBUINT* bbt_8=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomu)->scales + 1;
				BBUINT* bbt_9=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomu)->scales + 1;
				((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomu,1))[(*(bbt_9)) * ((BBUINT)_m_Gradient_Coder_v05_f) + (*(bbt_9+1)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomu,1))[(*(bbt_8)) * ((BBUINT)_m_Gradient_Coder_v05_f) + (*(bbt_8+1)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]-(_m_Gradient_Coder_v05_range/2));
				BBUINT* bbt_10=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomv)->scales + 1;
				((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomv,1))[(*(bbt_10)) * ((BBUINT)_m_Gradient_Coder_v05_f) + (*(bbt_10+1)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=random_core_Rand(_m_Gradient_Coder_v05_range,1);
				BBUINT* bbt_11=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomv)->scales + 1;
				BBUINT* bbt_12=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomv)->scales + 1;
				((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomv,1))[(*(bbt_12)) * ((BBUINT)_m_Gradient_Coder_v05_f) + (*(bbt_12+1)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomv,1))[(*(bbt_11)) * ((BBUINT)_m_Gradient_Coder_v05_f) + (*(bbt_11+1)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]-(_m_Gradient_Coder_v05_range/2));
			}
		}
	}
	return 0;
}
BBINT _m_Gradient_Coder_v05_Clamp255(BBFLOAT bbt_value){
	if(bbt_value<0.00000000f){
		return 0;
	}
	if(bbt_value>255.000000f){
		return 255;
	}
	return ((BBINT)bbt_value);
}
BBINT _m_Gradient_Coder_v05_secondsToStringDaysAndHours(BBINT bbt_seconds){
	BBINT bbt_days=(bbt_seconds/86400);
	BBINT bbt_hours=((bbt_seconds % 86400)/3600);
	BBINT bbt_minutes=((bbt_seconds % 3600)/60);
	BBINT bbt_secs=(bbt_seconds % 60);
	if(((bbt_hours<10) && (bbt_minutes<10)) && (bbt_secs<10)){
		_m_Gradient_Coder_v05_stringElapsedTime=bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringFromInt(bbt_days),((BBString*)&_s29)),((BBString*)&_s30)),bbStringFromInt(bbt_hours)),((BBString*)&_s31)),((BBString*)&_s30)),bbStringFromInt(bbt_minutes)),((BBString*)&_s31)),((BBString*)&_s30)),bbStringFromInt(bbt_secs));
	}
	if(((bbt_hours<10) && (bbt_minutes<10)) && (9<bbt_secs)){
		_m_Gradient_Coder_v05_stringElapsedTime=bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringFromInt(bbt_days),((BBString*)&_s29)),((BBString*)&_s30)),bbStringFromInt(bbt_hours)),((BBString*)&_s31)),((BBString*)&_s30)),bbStringFromInt(bbt_minutes)),((BBString*)&_s31)),bbStringFromInt(bbt_secs));
	}
	if(((bbt_hours<10) && (9<bbt_minutes)) && (bbt_secs<10)){
		_m_Gradient_Coder_v05_stringElapsedTime=bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringFromInt(bbt_days),((BBString*)&_s29)),((BBString*)&_s30)),bbStringFromInt(bbt_hours)),((BBString*)&_s31)),bbStringFromInt(bbt_minutes)),((BBString*)&_s31)),((BBString*)&_s30)),bbStringFromInt(bbt_secs));
	}
	if(((bbt_hours<10) && (9<bbt_minutes)) && (9<bbt_secs)){
		_m_Gradient_Coder_v05_stringElapsedTime=bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringFromInt(bbt_days),((BBString*)&_s29)),((BBString*)&_s30)),bbStringFromInt(bbt_hours)),((BBString*)&_s31)),bbStringFromInt(bbt_minutes)),((BBString*)&_s31)),bbStringFromInt(bbt_secs));
	}
	if(((9<bbt_hours) && (9<bbt_minutes)) && (bbt_secs<10)){
		_m_Gradient_Coder_v05_stringElapsedTime=bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringFromInt(bbt_days),((BBString*)&_s29)),bbStringFromInt(bbt_hours)),((BBString*)&_s31)),bbStringFromInt(bbt_minutes)),((BBString*)&_s31)),((BBString*)&_s30)),bbStringFromInt(bbt_secs));
	}
	if(((9<bbt_hours) && (9<bbt_minutes)) && (9<bbt_secs)){
		_m_Gradient_Coder_v05_stringElapsedTime=bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringFromInt(bbt_days),((BBString*)&_s29)),bbStringFromInt(bbt_hours)),((BBString*)&_s31)),bbStringFromInt(bbt_minutes)),((BBString*)&_s31)),bbStringFromInt(bbt_secs));
	}
	if(((9<bbt_hours) && (bbt_minutes<10)) && (bbt_secs<10)){
		_m_Gradient_Coder_v05_stringElapsedTime=bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringFromInt(bbt_days),((BBString*)&_s29)),bbStringFromInt(bbt_hours)),((BBString*)&_s31)),((BBString*)&_s30)),bbStringFromInt(bbt_minutes)),((BBString*)&_s31)),((BBString*)&_s30)),bbStringFromInt(bbt_secs));
	}
	if(((9<bbt_hours) && (bbt_minutes<10)) && (9<bbt_secs)){
		_m_Gradient_Coder_v05_stringElapsedTime=bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringFromInt(bbt_days),((BBString*)&_s29)),bbStringFromInt(bbt_hours)),((BBString*)&_s31)),((BBString*)&_s30)),bbStringFromInt(bbt_minutes)),((BBString*)&_s31)),bbStringFromInt(bbt_secs));
	}
	return 0;
}
static int _bb_main_inited = 0;
int _bb_main(){
	if (!_bb_main_inited) {
		_bb_main_inited = 1;
		GC_add_roots(&_m_Gradient_Coder_v05_largura, &_m_Gradient_Coder_v05_size + 1);
		__bb_brl_blitz_blitz();
		__bb_brl_appstub_appstub();
		__bb_brl_audio_audio();
		__bb_brl_bank_bank();
		__bb_brl_bankstream_bankstream();
		__bb_brl_base64_base64();
		__bb_brl_basic_basic();
		__bb_brl_bmploader_bmploader();
		__bb_brl_bytebuffer_bytebuffer();
		__bb_brl_clipboard_clipboard();
		__bb_brl_collections_collections();
		__bb_brl_d3d7max2d_d3d7max2d();
		__bb_brl_d3d9max2d_d3d9max2d();
		__bb_brl_directsoundaudio_directsoundaudio();
		__bb_brl_eventqueue_eventqueue();
		__bb_brl_freeaudioaudio_freeaudioaudio();
		__bb_brl_freetypefont_freetypefont();
		__bb_brl_glgraphics_glgraphics();
		__bb_brl_glmax2d_glmax2d();
		__bb_brl_gnet_gnet();
		__bb_brl_jpgloader_jpgloader();
		__bb_brl_map_map();
		__bb_brl_matrix_matrix();
		__bb_brl_maxlua_maxlua();
		__bb_brl_maxunit_maxunit();
		__bb_brl_maxutil_maxutil();
		__bb_brl_objectlist_objectlist();
		__bb_brl_oggloader_oggloader();
		__bb_brl_openalaudio_openalaudio();
		__bb_brl_platform_platform();
		__bb_brl_pngloader_pngloader();
		__bb_brl_polygon_polygon();
		__bb_brl_quaternion_quaternion();
		__bb_brl_retro_retro();
		__bb_brl_tgaloader_tgaloader();
		__bb_brl_threadpool_threadpool();
		__bb_brl_timer_timer();
		__bb_brl_timerdefault_timerdefault();
		__bb_brl_utf8stream_utf8stream();
		__bb_brl_uuid_uuid();
		__bb_brl_volumes_volumes();
		__bb_brl_wavloader_wavloader();
		__bb_pub_freejoy_freejoy();
		__bb_pub_freeprocess_freeprocess();
		__bb_pub_glad_glad();
		__bb_pub_nfd_nfd();
		__bb_pub_nx_nx();
		__bb_pub_opengles_opengles();
		__bb_pub_opengles3_opengles3();
		__bb_pub_vulkan_vulkan();
		__bb_pub_xmmintrin_xmmintrin();
		brl_standardio_Print((BBString*)&_s11);
		_m_Gradient_Coder_v05_Stringdata=brl_standardio_Input((BBString*)&_s12);
		_m_Gradient_Coder_v05_Stringiter=brl_standardio_Input((BBString*)&_s13);
		_m_Gradient_Coder_v05_Stringrange=brl_standardio_Input((BBString*)&_s14);
		_m_Gradient_Coder_v05_Stringadverage=brl_standardio_Input((BBString*)&_s15);
		_m_Gradient_Coder_v05_Stringyd=brl_standardio_Input((BBString*)&_s16);
		_m_Gradient_Coder_v05_Stringud=brl_standardio_Input((BBString*)&_s17);
		_m_Gradient_Coder_v05_Stringvd=brl_standardio_Input((BBString*)&_s18);
		_m_Gradient_Coder_v05_filestringoutdat=bbStringConcat(_m_Gradient_Coder_v05_Stringdata,((BBString*)&_s19));
		_m_Gradient_Coder_v05_filestringoutdatpaq8o=bbStringConcat(_m_Gradient_Coder_v05_Stringdata,((BBString*)&_s20));
		_m_Gradient_Coder_v05_filestringinbmp=_m_Gradient_Coder_v05_Stringdata;
		_m_Gradient_Coder_v05_filestringoutdatpng=bbStringConcat(_m_Gradient_Coder_v05_Stringdata,((BBString*)&_s21));
		_m_Gradient_Coder_v05_file001=(struct brl_stream_TStream_obj*)brl_filesystem_WriteFile((BBOBJECT)_m_Gradient_Coder_v05_filestringoutdat);
		_m_Gradient_Coder_v05_begintime=((BBFLOAT)bbMilliSecs());
		_m_Gradient_Coder_v05_begintime2=((BBDOUBLE)bbMilliSecs());
		brl_graphics_Graphics(1680,1040,0,60,0LL,-1,-1);
		_m_Gradient_Coder_v05_imagemap=(struct brl_pixmap_TPixmap_obj*)brl_pixmap_LoadPixmap((BBOBJECT)_m_Gradient_Coder_v05_filestringinbmp);
		_m_Gradient_Coder_v05_largura=brl_pixmap_PixmapWidth((struct brl_pixmap_TPixmap_obj*)_m_Gradient_Coder_v05_imagemap);
		_m_Gradient_Coder_v05_altura=brl_pixmap_PixmapHeight((struct brl_pixmap_TPixmap_obj*)_m_Gradient_Coder_v05_imagemap);
		_m_Gradient_Coder_v05_iterations=bbStringToInt(_m_Gradient_Coder_v05_Stringiter);
		_m_Gradient_Coder_v05_adverage=bbStringToInt(_m_Gradient_Coder_v05_Stringadverage);
		_m_Gradient_Coder_v05_range=bbStringToInt(_m_Gradient_Coder_v05_Stringrange);
		_m_Gradient_Coder_v05_accuracy=bbStringToInt(_m_Gradient_Coder_v05_Stringaccuracy);
		_m_Gradient_Coder_v05_tolerance=bbStringToInt(_m_Gradient_Coder_v05_stringtolerance);
		_m_Gradient_Coder_v05_noise=bbStringToInt(_m_Gradient_Coder_v05_Stringnoise);
		_m_Gradient_Coder_v05_gridx=_m_Gradient_Coder_v05_adverage;
		_m_Gradient_Coder_v05_gridy=_m_Gradient_Coder_v05_adverage;
		_m_Gradient_Coder_v05_divisory=bbStringToInt(_m_Gradient_Coder_v05_Stringyd);
		_m_Gradient_Coder_v05_divisoru=bbStringToInt(_m_Gradient_Coder_v05_Stringud);
		_m_Gradient_Coder_v05_divisorv=bbStringToInt(_m_Gradient_Coder_v05_Stringvd);
		_m_Gradient_Coder_v05_valuered=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuegreen=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueblue=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuered2=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuegreen2=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueblue2=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuey=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueu=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuev=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuey2=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueu2=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuev2=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuey3=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueu3=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuev3=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuesya=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuesua=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuesva=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuesyaf=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuesuaf=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuesvaf=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_tabelarandomy=bbArrayNew("i", 3, (_m_Gradient_Coder_v05_iterations+1), (_m_Gradient_Coder_v05_gridx+1), (_m_Gradient_Coder_v05_gridy+1));
		_m_Gradient_Coder_v05_tabelarandomu=bbArrayNew("i", 3, (_m_Gradient_Coder_v05_iterations+1), (_m_Gradient_Coder_v05_gridx+1), (_m_Gradient_Coder_v05_gridy+1));
		_m_Gradient_Coder_v05_tabelarandomv=bbArrayNew("i", 3, (_m_Gradient_Coder_v05_iterations+1), (_m_Gradient_Coder_v05_gridx+1), (_m_Gradient_Coder_v05_gridy+1));
		_m_Gradient_Coder_v05_valuesy=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuesu=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuesv=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueyf=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueuf=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuevf=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueyf2=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueuf2=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuevf2=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueyf3=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueuf3=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuevf3=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueyf4=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valueuf4=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_valuevf4=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_tabelafinaly=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_tabelafinalu=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_tabelafinalv=bbArrayNew("i", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_errory=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_erroru=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		_m_Gradient_Coder_v05_errorv=bbArrayNew("b", 2, _m_Gradient_Coder_v05_largura, _m_Gradient_Coder_v05_altura);
		BBINT bbt_=(_m_Gradient_Coder_v05_altura-1);
		for(_m_Gradient_Coder_v05_y=0;(_m_Gradient_Coder_v05_y<=bbt_);_m_Gradient_Coder_v05_y=(_m_Gradient_Coder_v05_y+1)){
			BBINT bbt_2=(_m_Gradient_Coder_v05_largura-1);
			for(_m_Gradient_Coder_v05_x=0;(_m_Gradient_Coder_v05_x<=bbt_2);_m_Gradient_Coder_v05_x=(_m_Gradient_Coder_v05_x+1)){
				BBINT bbt_pixel=brl_pixmap_ReadPixel((struct brl_pixmap_TPixmap_obj*)_m_Gradient_Coder_v05_imagemap,_m_Gradient_Coder_v05_x,_m_Gradient_Coder_v05_y);
				BBUINT* bbt_3=((BBARRAY)_m_Gradient_Coder_v05_valuered)->scales + 1;
				((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuered,1))[(*(bbt_3)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=((BBBYTE)((unsigned int)(((unsigned int)(bbt_pixel)>>(unsigned int)(16)))&(unsigned int)(255)));
				BBUINT* bbt_4=((BBARRAY)_m_Gradient_Coder_v05_valuegreen)->scales + 1;
				((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuegreen,1))[(*(bbt_4)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=((BBBYTE)((unsigned int)(((unsigned int)(bbt_pixel)>>(unsigned int)(8)))&(unsigned int)(255)));
				BBUINT* bbt_5=((BBARRAY)_m_Gradient_Coder_v05_valueblue)->scales + 1;
				((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueblue,1))[(*(bbt_5)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=((BBBYTE)((unsigned int)(bbt_pixel)&(unsigned int)(255)));
				BBUINT* bbt_6=((BBARRAY)_m_Gradient_Coder_v05_valuered)->scales + 1;
				BBUINT* bbt_7=((BBARRAY)_m_Gradient_Coder_v05_valuegreen)->scales + 1;
				BBUINT* bbt_8=((BBARRAY)_m_Gradient_Coder_v05_valueblue)->scales + 1;
				BBUINT* bbt_9=((BBARRAY)_m_Gradient_Coder_v05_valuey)->scales + 1;
				((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey,1))[(*(bbt_9)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=((BBBYTE)((((0.257f*((BBFLOAT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuered,1))[(*(bbt_6)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]))+(0.504f*((BBFLOAT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuegreen,1))[(*(bbt_7)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])))+(0.098f*((BBFLOAT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueblue,1))[(*(bbt_8)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])))+16.0000000f));
				BBUINT* bbt_10=((BBARRAY)_m_Gradient_Coder_v05_valuered)->scales + 1;
				BBUINT* bbt_11=((BBARRAY)_m_Gradient_Coder_v05_valuegreen)->scales + 1;
				BBUINT* bbt_12=((BBARRAY)_m_Gradient_Coder_v05_valueblue)->scales + 1;
				BBUINT* bbt_13=((BBARRAY)_m_Gradient_Coder_v05_valueu)->scales + 1;
				((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu,1))[(*(bbt_13)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=((BBBYTE)((((-0.148f*((BBFLOAT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuered,1))[(*(bbt_10)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]))-(0.291f*((BBFLOAT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuegreen,1))[(*(bbt_11)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])))+(0.439f*((BBFLOAT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueblue,1))[(*(bbt_12)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])))+128.000000f));
				BBUINT* bbt_14=((BBARRAY)_m_Gradient_Coder_v05_valuered)->scales + 1;
				BBUINT* bbt_15=((BBARRAY)_m_Gradient_Coder_v05_valuegreen)->scales + 1;
				BBUINT* bbt_16=((BBARRAY)_m_Gradient_Coder_v05_valueblue)->scales + 1;
				BBUINT* bbt_17=((BBARRAY)_m_Gradient_Coder_v05_valuev)->scales + 1;
				((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev,1))[(*(bbt_17)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=((BBBYTE)((((0.439f*((BBFLOAT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuered,1))[(*(bbt_14)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]))-(0.368f*((BBFLOAT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuegreen,1))[(*(bbt_15)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])))-(0.071f*((BBFLOAT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueblue,1))[(*(bbt_16)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])))+128.000000f));
			}
		}
		brl_stream_WriteString2((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,bbStringConcat(bbStringConcat(bbStringFromInt(_m_Gradient_Coder_v05_largura),((BBString*)&_s34)),((BBString*)&_s35)));
		brl_stream_WriteString2((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,bbStringConcat(bbStringConcat(bbStringFromInt(_m_Gradient_Coder_v05_altura),((BBString*)&_s34)),((BBString*)&_s35)));
		_m_Gradient_Coder_v05_createrandoms();
		_m_Gradient_Coder_v05_maxnumfinal=0.0000000000000000;
		_m_Gradient_Coder_v05_trys=0;
		BBINT bbt_18=((_m_Gradient_Coder_v05_altura-1)-_m_Gradient_Coder_v05_gridy);
		for(_m_Gradient_Coder_v05_y=0;(_m_Gradient_Coder_v05_y<=bbt_18);_m_Gradient_Coder_v05_y=(_m_Gradient_Coder_v05_y+1)){
			BBINT bbt_19=((_m_Gradient_Coder_v05_largura-1)-_m_Gradient_Coder_v05_gridx);
			for(_m_Gradient_Coder_v05_x=0;(_m_Gradient_Coder_v05_x<=bbt_19);_m_Gradient_Coder_v05_x=(_m_Gradient_Coder_v05_x+1)){
				BBINT bbt_20=(_m_Gradient_Coder_v05_gridy-1);
				for(_m_Gradient_Coder_v05_y1=0;(_m_Gradient_Coder_v05_y1<=bbt_20);_m_Gradient_Coder_v05_y1=(_m_Gradient_Coder_v05_y1+1)){
					BBINT bbt_21=(_m_Gradient_Coder_v05_gridx-1);
					for(_m_Gradient_Coder_v05_x1=0;(_m_Gradient_Coder_v05_x1<=bbt_21);_m_Gradient_Coder_v05_x1=(_m_Gradient_Coder_v05_x1+1)){
						BBUINT* bbt_22=((BBARRAY)_m_Gradient_Coder_v05_valuey)->scales + 1;
						BBUINT* bbt_23=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_23)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey,1))[(*(bbt_22)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))];
						BBUINT* bbt_24=((BBARRAY)_m_Gradient_Coder_v05_valueu)->scales + 1;
						BBUINT* bbt_25=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_25)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu,1))[(*(bbt_24)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))];
						BBUINT* bbt_26=((BBARRAY)_m_Gradient_Coder_v05_valuev)->scales + 1;
						BBUINT* bbt_27=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_27)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev,1))[(*(bbt_26)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))];
						if((_m_Gradient_Coder_v05_x1==0) && (_m_Gradient_Coder_v05_y1==0)){
							BBUINT* bbt_28=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
							brl_stream_WriteByte((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_28)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]));
							BBUINT* bbt_29=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
							brl_stream_WriteByte((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_29)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]));
							BBUINT* bbt_30=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
							brl_stream_WriteByte((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_30)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]));
						}
					}
				}
				BBINT bbt_31=(_m_Gradient_Coder_v05_gridy-1);
				for(_m_Gradient_Coder_v05_y1=0;(_m_Gradient_Coder_v05_y1<=bbt_31);_m_Gradient_Coder_v05_y1=(_m_Gradient_Coder_v05_y1+1)){
					BBINT bbt_32=(_m_Gradient_Coder_v05_gridx-1);
					for(_m_Gradient_Coder_v05_x1=0;(_m_Gradient_Coder_v05_x1<=bbt_32);_m_Gradient_Coder_v05_x1=(_m_Gradient_Coder_v05_x1+1)){
						BBUINT* bbt_33=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_34=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_35=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_36=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_37=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_38=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_39=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_40=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_41=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_42=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_43=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_44=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
						BBUINT* bbt_45=((BBARRAY)_m_Gradient_Coder_v05_valuesy)->scales + 1;
						((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesy,1))[(*(bbt_45)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)]=((BBBYTE)(((((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_33)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_34)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_35)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)_m_Gradient_Coder_v05_y)]))/_m_Gradient_Coder_v05_gridx)*_m_Gradient_Coder_v05_x1))+(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_36)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_37)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_38)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]))/_m_Gradient_Coder_v05_gridy)*_m_Gradient_Coder_v05_y1)))+(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_39)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_40)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_41)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]))/_m_Gradient_Coder_v05_gridx)*_m_Gradient_Coder_v05_x1)))+(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_42)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)_m_Gradient_Coder_v05_y)])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_43)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)_m_Gradient_Coder_v05_y)]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_44)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]))/_m_Gradient_Coder_v05_gridy)*_m_Gradient_Coder_v05_y1)))/4));
						BBUINT* bbt_46=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_47=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_48=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_49=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_50=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_51=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_52=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_53=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_54=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_55=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_56=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_57=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
						BBUINT* bbt_58=((BBARRAY)_m_Gradient_Coder_v05_valuesu)->scales + 1;
						((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesu,1))[(*(bbt_58)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)]=((BBBYTE)(((((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_46)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_47)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_48)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)_m_Gradient_Coder_v05_y)]))/_m_Gradient_Coder_v05_gridx)*_m_Gradient_Coder_v05_x1))+(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_49)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_50)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_51)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]))/_m_Gradient_Coder_v05_gridy)*_m_Gradient_Coder_v05_y1)))+(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_52)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_53)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_54)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]))/_m_Gradient_Coder_v05_gridx)*_m_Gradient_Coder_v05_x1)))+(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_55)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)_m_Gradient_Coder_v05_y)])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_56)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)_m_Gradient_Coder_v05_y)]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_57)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]))/_m_Gradient_Coder_v05_gridy)*_m_Gradient_Coder_v05_y1)))/4));
						BBUINT* bbt_59=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_60=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_61=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_62=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_63=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_64=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_65=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_66=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_67=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_68=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_69=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_70=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
						BBUINT* bbt_71=((BBARRAY)_m_Gradient_Coder_v05_valuesv)->scales + 1;
						((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesv,1))[(*(bbt_71)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)]=((BBBYTE)(((((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_59)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_60)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_61)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)_m_Gradient_Coder_v05_y)]))/_m_Gradient_Coder_v05_gridx)*_m_Gradient_Coder_v05_x1))+(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_62)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_63)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_64)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]))/_m_Gradient_Coder_v05_gridy)*_m_Gradient_Coder_v05_y1)))+(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_65)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_66)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_67)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]))/_m_Gradient_Coder_v05_gridx)*_m_Gradient_Coder_v05_x1)))+(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_68)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)_m_Gradient_Coder_v05_y)])+((((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_69)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)_m_Gradient_Coder_v05_y)]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_70)) * ((BBUINT)(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1))) + ((BBUINT)(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1)))]))/_m_Gradient_Coder_v05_gridy)*_m_Gradient_Coder_v05_y1)))/4));
					}
				}
				_m_Gradient_Coder_v05_randomiter=-1;
				_m_Gradient_Coder_v05_maxnum=((768*_m_Gradient_Coder_v05_gridx)*_m_Gradient_Coder_v05_gridy);
				do{
					_m_Gradient_Coder_v05_randomiter=(_m_Gradient_Coder_v05_randomiter+1);
					_m_Gradient_Coder_v05_insertiter=0;
					BBINT bbt_72=(_m_Gradient_Coder_v05_gridy-1);
					for(_m_Gradient_Coder_v05_y1=0;(_m_Gradient_Coder_v05_y1<=bbt_72);_m_Gradient_Coder_v05_y1=(_m_Gradient_Coder_v05_y1+1)){
						BBINT bbt_73=(_m_Gradient_Coder_v05_gridx-1);
						for(_m_Gradient_Coder_v05_x1=0;(_m_Gradient_Coder_v05_x1<=bbt_73);_m_Gradient_Coder_v05_x1=(_m_Gradient_Coder_v05_x1+1)){
							BBUINT* bbt_74=((BBARRAY)_m_Gradient_Coder_v05_valuesy)->scales + 1;
							BBUINT* bbt_75=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomy)->scales + 1;
							BBUINT* bbt_76=((BBARRAY)_m_Gradient_Coder_v05_valueyf)->scales + 1;
							((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf,1))[(*(bbt_76)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesy,1))[(*(bbt_74)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomy,1))[(*(bbt_75)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_75+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)]));
							BBUINT* bbt_77=((BBARRAY)_m_Gradient_Coder_v05_valuesu)->scales + 1;
							BBUINT* bbt_78=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomu)->scales + 1;
							BBUINT* bbt_79=((BBARRAY)_m_Gradient_Coder_v05_valueuf)->scales + 1;
							((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf,1))[(*(bbt_79)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesu,1))[(*(bbt_77)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomu,1))[(*(bbt_78)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_78+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)]));
							BBUINT* bbt_80=((BBARRAY)_m_Gradient_Coder_v05_valuesv)->scales + 1;
							BBUINT* bbt_81=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomv)->scales + 1;
							BBUINT* bbt_82=((BBARRAY)_m_Gradient_Coder_v05_valuevf)->scales + 1;
							((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf,1))[(*(bbt_82)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesv,1))[(*(bbt_80)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomv,1))[(*(bbt_81)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_81+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)]));
							BBUINT* bbt_83=((BBARRAY)_m_Gradient_Coder_v05_valueyf)->scales + 1;
							BBUINT* bbt_84=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
							BBUINT* bbt_85=((BBARRAY)_m_Gradient_Coder_v05_valueyf2)->scales + 1;
							((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf2,1))[(*(bbt_85)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf,1))[(*(bbt_83)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_84)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]));
							BBUINT* bbt_86=((BBARRAY)_m_Gradient_Coder_v05_valueuf)->scales + 1;
							BBUINT* bbt_87=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
							BBUINT* bbt_88=((BBARRAY)_m_Gradient_Coder_v05_valueuf2)->scales + 1;
							((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf2,1))[(*(bbt_88)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf,1))[(*(bbt_86)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_87)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]));
							BBUINT* bbt_89=((BBARRAY)_m_Gradient_Coder_v05_valuevf)->scales + 1;
							BBUINT* bbt_90=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
							BBUINT* bbt_91=((BBARRAY)_m_Gradient_Coder_v05_valuevf2)->scales + 1;
							((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf2,1))[(*(bbt_91)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBINT)(((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf,1))[(*(bbt_89)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]-((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_90)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]));
							BBUINT* bbt_92=((BBARRAY)_m_Gradient_Coder_v05_valueyf2)->scales + 1;
							BBUINT* bbt_93=((BBARRAY)_m_Gradient_Coder_v05_valueuf2)->scales + 1;
							BBUINT* bbt_94=((BBARRAY)_m_Gradient_Coder_v05_valuevf2)->scales + 1;
							_m_Gradient_Coder_v05_insertiter=(((_m_Gradient_Coder_v05_insertiter+brl_blitz_Abs(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf2,1))[(*(bbt_92)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))+brl_blitz_Abs(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf2,1))[(*(bbt_93)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))+brl_blitz_Abs(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf2,1))[(*(bbt_94)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]));
						}
					}
					if(_m_Gradient_Coder_v05_insertiter<_m_Gradient_Coder_v05_maxnum){
						_m_Gradient_Coder_v05_maxnum=_m_Gradient_Coder_v05_insertiter;
						_m_Gradient_Coder_v05_insertfinal=0.0000000000000000;
						_m_Gradient_Coder_v05_finaliter=_m_Gradient_Coder_v05_randomiter;
						BBINT bbt_95=(_m_Gradient_Coder_v05_gridy-1);
						for(_m_Gradient_Coder_v05_y1=0;(_m_Gradient_Coder_v05_y1<=bbt_95);_m_Gradient_Coder_v05_y1=(_m_Gradient_Coder_v05_y1+1)){
							BBINT bbt_96=(_m_Gradient_Coder_v05_gridx-1);
							for(_m_Gradient_Coder_v05_x1=0;(_m_Gradient_Coder_v05_x1<=bbt_96);_m_Gradient_Coder_v05_x1=(_m_Gradient_Coder_v05_x1+1)){
								BBUINT* bbt_97=((BBARRAY)_m_Gradient_Coder_v05_valuesy)->scales + 1;
								BBUINT* bbt_98=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomy)->scales + 1;
								BBUINT* bbt_99=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
								BBUINT* bbt_100=((BBARRAY)_m_Gradient_Coder_v05_valueyf4)->scales + 1;
								((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf4,1))[(*(bbt_100)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=(((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesy,1))[(*(bbt_97)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomy,1))[(*(bbt_98)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_98+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_99)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))/_m_Gradient_Coder_v05_divisory);
								BBUINT* bbt_101=((BBARRAY)_m_Gradient_Coder_v05_valuesu)->scales + 1;
								BBUINT* bbt_102=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomu)->scales + 1;
								BBUINT* bbt_103=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
								BBUINT* bbt_104=((BBARRAY)_m_Gradient_Coder_v05_valueuf4)->scales + 1;
								((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf4,1))[(*(bbt_104)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=(((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesu,1))[(*(bbt_101)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomu,1))[(*(bbt_102)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_102+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_103)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))/_m_Gradient_Coder_v05_divisoru);
								BBUINT* bbt_105=((BBARRAY)_m_Gradient_Coder_v05_valuesv)->scales + 1;
								BBUINT* bbt_106=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomv)->scales + 1;
								BBUINT* bbt_107=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
								BBUINT* bbt_108=((BBARRAY)_m_Gradient_Coder_v05_valuevf4)->scales + 1;
								((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf4,1))[(*(bbt_108)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=(((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesv,1))[(*(bbt_105)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomv,1))[(*(bbt_106)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_106+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_107)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))/_m_Gradient_Coder_v05_divisorv);
								BBUINT* bbt_109=((BBARRAY)_m_Gradient_Coder_v05_valuesy)->scales + 1;
								BBUINT* bbt_110=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomy)->scales + 1;
								BBUINT* bbt_111=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
								if(((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesy,1))[(*(bbt_109)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomy,1))[(*(bbt_110)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_110+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_111)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))>0){
									BBUINT* bbt_112=((BBARRAY)_m_Gradient_Coder_v05_valuesy)->scales + 1;
									BBUINT* bbt_113=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomy)->scales + 1;
									BBUINT* bbt_114=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
									BBUINT* bbt_115=((BBARRAY)_m_Gradient_Coder_v05_valueyf3)->scales + 1;
									((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf3,1))[(*(bbt_115)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=(((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesy,1))[(*(bbt_112)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomy,1))[(*(bbt_113)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_113+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_114)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))/_m_Gradient_Coder_v05_divisory);
									BBUINT* bbt_116=((BBARRAY)_m_Gradient_Coder_v05_valueyf3)->scales + 1;
									_m_Gradient_Coder_v05_insertfinal=(_m_Gradient_Coder_v05_insertfinal+((BBDOUBLE)brl_blitz_Abs(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf3,1))[(*(bbt_116)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])));
								}else{
									BBUINT* bbt_117=((BBARRAY)_m_Gradient_Coder_v05_valuesy)->scales + 1;
									BBUINT* bbt_118=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomy)->scales + 1;
									BBUINT* bbt_119=((BBARRAY)_m_Gradient_Coder_v05_valuey2)->scales + 1;
									BBUINT* bbt_120=((BBARRAY)_m_Gradient_Coder_v05_valueyf3)->scales + 1;
									((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf3,1))[(*(bbt_120)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesy,1))[(*(bbt_117)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomy,1))[(*(bbt_118)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_118+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey2,1))[(*(bbt_119)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))/_m_Gradient_Coder_v05_divisory)+128);
									BBUINT* bbt_121=((BBARRAY)_m_Gradient_Coder_v05_valueyf3)->scales + 1;
									_m_Gradient_Coder_v05_insertfinal=(_m_Gradient_Coder_v05_insertfinal+((BBDOUBLE)(brl_blitz_Abs(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf3,1))[(*(bbt_121)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])-128)));
								}
								BBUINT* bbt_122=((BBARRAY)_m_Gradient_Coder_v05_valuesu)->scales + 1;
								BBUINT* bbt_123=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomu)->scales + 1;
								BBUINT* bbt_124=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
								if(((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesu,1))[(*(bbt_122)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomu,1))[(*(bbt_123)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_123+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_124)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))>0){
									BBUINT* bbt_125=((BBARRAY)_m_Gradient_Coder_v05_valuesu)->scales + 1;
									BBUINT* bbt_126=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomu)->scales + 1;
									BBUINT* bbt_127=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
									BBUINT* bbt_128=((BBARRAY)_m_Gradient_Coder_v05_valueuf3)->scales + 1;
									((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf3,1))[(*(bbt_128)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=(((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesu,1))[(*(bbt_125)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomu,1))[(*(bbt_126)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_126+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_127)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))/_m_Gradient_Coder_v05_divisoru);
									BBUINT* bbt_129=((BBARRAY)_m_Gradient_Coder_v05_valueuf3)->scales + 1;
									_m_Gradient_Coder_v05_insertfinal=(_m_Gradient_Coder_v05_insertfinal+((BBDOUBLE)brl_blitz_Abs(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf3,1))[(*(bbt_129)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])));
								}else{
									BBUINT* bbt_130=((BBARRAY)_m_Gradient_Coder_v05_valuesu)->scales + 1;
									BBUINT* bbt_131=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomu)->scales + 1;
									BBUINT* bbt_132=((BBARRAY)_m_Gradient_Coder_v05_valueu2)->scales + 1;
									BBUINT* bbt_133=((BBARRAY)_m_Gradient_Coder_v05_valueuf3)->scales + 1;
									((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf3,1))[(*(bbt_133)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesu,1))[(*(bbt_130)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomu,1))[(*(bbt_131)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_131+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu2,1))[(*(bbt_132)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))/_m_Gradient_Coder_v05_divisoru)+128);
									BBUINT* bbt_134=((BBARRAY)_m_Gradient_Coder_v05_valueuf3)->scales + 1;
									_m_Gradient_Coder_v05_insertfinal=(_m_Gradient_Coder_v05_insertfinal+((BBDOUBLE)(brl_blitz_Abs(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf3,1))[(*(bbt_134)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])-128)));
								}
								BBUINT* bbt_135=((BBARRAY)_m_Gradient_Coder_v05_valuesv)->scales + 1;
								BBUINT* bbt_136=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomv)->scales + 1;
								BBUINT* bbt_137=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
								if(((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesv,1))[(*(bbt_135)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomv,1))[(*(bbt_136)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_136+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_137)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))>0){
									BBUINT* bbt_138=((BBARRAY)_m_Gradient_Coder_v05_valuesv)->scales + 1;
									BBUINT* bbt_139=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomv)->scales + 1;
									BBUINT* bbt_140=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
									BBUINT* bbt_141=((BBARRAY)_m_Gradient_Coder_v05_valuevf3)->scales + 1;
									((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf3,1))[(*(bbt_141)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=(((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesv,1))[(*(bbt_138)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomv,1))[(*(bbt_139)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_139+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_140)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))/_m_Gradient_Coder_v05_divisorv);
									BBUINT* bbt_142=((BBARRAY)_m_Gradient_Coder_v05_valuevf3)->scales + 1;
									_m_Gradient_Coder_v05_insertfinal=(_m_Gradient_Coder_v05_insertfinal+((BBDOUBLE)brl_blitz_Abs(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf3,1))[(*(bbt_142)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])));
								}else{
									BBUINT* bbt_143=((BBARRAY)_m_Gradient_Coder_v05_valuesv)->scales + 1;
									BBUINT* bbt_144=((BBARRAY)_m_Gradient_Coder_v05_tabelarandomv)->scales + 1;
									BBUINT* bbt_145=((BBARRAY)_m_Gradient_Coder_v05_valuev2)->scales + 1;
									BBUINT* bbt_146=((BBARRAY)_m_Gradient_Coder_v05_valuevf3)->scales + 1;
									((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf3,1))[(*(bbt_146)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesv,1))[(*(bbt_143)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])+((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_tabelarandomv,1))[(*(bbt_144)) * ((BBUINT)_m_Gradient_Coder_v05_randomiter) + (*(bbt_144+1)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev2,1))[(*(bbt_145)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]))/_m_Gradient_Coder_v05_divisorv)+128);
									BBUINT* bbt_147=((BBARRAY)_m_Gradient_Coder_v05_valuevf3)->scales + 1;
									_m_Gradient_Coder_v05_insertfinal=(_m_Gradient_Coder_v05_insertfinal+((BBDOUBLE)(brl_blitz_Abs(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf3,1))[(*(bbt_147)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])-128)));
								}
								BBUINT* bbt_148=((BBARRAY)_m_Gradient_Coder_v05_valuesy)->scales + 1;
								BBUINT* bbt_149=((BBARRAY)_m_Gradient_Coder_v05_valueyf4)->scales + 1;
								BBUINT* bbt_150=((BBARRAY)_m_Gradient_Coder_v05_valuey3)->scales + 1;
								((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey3,1))[(*(bbt_150)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesy,1))[(*(bbt_148)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf4,1))[(*(bbt_149)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]*_m_Gradient_Coder_v05_divisory)));
								BBUINT* bbt_151=((BBARRAY)_m_Gradient_Coder_v05_valuesu)->scales + 1;
								BBUINT* bbt_152=((BBARRAY)_m_Gradient_Coder_v05_valueuf4)->scales + 1;
								BBUINT* bbt_153=((BBARRAY)_m_Gradient_Coder_v05_valueu3)->scales + 1;
								((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu3,1))[(*(bbt_153)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesu,1))[(*(bbt_151)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf4,1))[(*(bbt_152)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]*_m_Gradient_Coder_v05_divisoru)));
								BBUINT* bbt_154=((BBARRAY)_m_Gradient_Coder_v05_valuesv)->scales + 1;
								BBUINT* bbt_155=((BBARRAY)_m_Gradient_Coder_v05_valuevf4)->scales + 1;
								BBUINT* bbt_156=((BBARRAY)_m_Gradient_Coder_v05_valuev3)->scales + 1;
								((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev3,1))[(*(bbt_156)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuesv,1))[(*(bbt_154)) * ((BBUINT)_m_Gradient_Coder_v05_x1) + ((BBUINT)_m_Gradient_Coder_v05_y1)])-(((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf4,1))[(*(bbt_155)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]*_m_Gradient_Coder_v05_divisorv)));
							}
						}
					}
				}while(!(_m_Gradient_Coder_v05_iterations==_m_Gradient_Coder_v05_randomiter));
				_m_Gradient_Coder_v05_maxinsertfinal=(_m_Gradient_Coder_v05_maxinsertfinal+_m_Gradient_Coder_v05_insertfinal);
				_m_Gradient_Coder_v05_maxnumfinal=(_m_Gradient_Coder_v05_maxnumfinal+((BBDOUBLE)_m_Gradient_Coder_v05_maxnum));
				_m_Gradient_Coder_v05_trys=(_m_Gradient_Coder_v05_trys+1);
				_m_Gradient_Coder_v05_valor1=(_m_Gradient_Coder_v05_finaliter/16777216);
				_m_Gradient_Coder_v05_valor2=((_m_Gradient_Coder_v05_finaliter-(_m_Gradient_Coder_v05_valor1*16777216))/65536);
				_m_Gradient_Coder_v05_valor3=((_m_Gradient_Coder_v05_finaliter-((_m_Gradient_Coder_v05_valor1*16777216)+(_m_Gradient_Coder_v05_valor2*65536)))/256);
				_m_Gradient_Coder_v05_valor4=(_m_Gradient_Coder_v05_finaliter-(((_m_Gradient_Coder_v05_valor1*16777216)+(_m_Gradient_Coder_v05_valor2*65536))+(_m_Gradient_Coder_v05_valor3*256)));
				brl_stream_WriteByte((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,_m_Gradient_Coder_v05_valor1);
				brl_stream_WriteByte((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,_m_Gradient_Coder_v05_valor2);
				brl_stream_WriteByte((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,_m_Gradient_Coder_v05_valor3);
				brl_stream_WriteByte((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,_m_Gradient_Coder_v05_valor4);
				BBINT bbt_157=(_m_Gradient_Coder_v05_gridy-1);
				for(_m_Gradient_Coder_v05_y1=0;(_m_Gradient_Coder_v05_y1<=bbt_157);_m_Gradient_Coder_v05_y1=(_m_Gradient_Coder_v05_y1+1)){
					BBINT bbt_158=(_m_Gradient_Coder_v05_gridx-1);
					for(_m_Gradient_Coder_v05_x1=0;(_m_Gradient_Coder_v05_x1<=bbt_158);_m_Gradient_Coder_v05_x1=(_m_Gradient_Coder_v05_x1+1)){
						BBUINT* bbt_159=((BBARRAY)_m_Gradient_Coder_v05_valueyf3)->scales + 1;
						_m_Gradient_Coder_v05_valor1=((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueyf3,1))[(*(bbt_159)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))];
						BBUINT* bbt_160=((BBARRAY)_m_Gradient_Coder_v05_valueuf3)->scales + 1;
						_m_Gradient_Coder_v05_valor1=((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valueuf3,1))[(*(bbt_160)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))];
						BBUINT* bbt_161=((BBARRAY)_m_Gradient_Coder_v05_valuevf3)->scales + 1;
						_m_Gradient_Coder_v05_valor1=((BBINT*)BBARRAYDATA(_m_Gradient_Coder_v05_valuevf3,1))[(*(bbt_161)) * ((BBUINT)(_m_Gradient_Coder_v05_x+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))];
						if((_m_Gradient_Coder_v05_y1>0) || (_m_Gradient_Coder_v05_x1>0)){
							brl_stream_WriteByte((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,_m_Gradient_Coder_v05_valor1);
							brl_stream_WriteByte((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,_m_Gradient_Coder_v05_valor2);
							brl_stream_WriteByte((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001,_m_Gradient_Coder_v05_valor3);
						}
					}
				}
				BBINT bbt_162=((_m_Gradient_Coder_v05_largura-1)-_m_Gradient_Coder_v05_gridx);
				for(_m_Gradient_Coder_v05_f=0;(_m_Gradient_Coder_v05_f<=bbt_162);_m_Gradient_Coder_v05_f=(_m_Gradient_Coder_v05_f+1)){
					BBINT bbt_163=(_m_Gradient_Coder_v05_gridy-1);
					for(_m_Gradient_Coder_v05_y1=0;(_m_Gradient_Coder_v05_y1<=bbt_163);_m_Gradient_Coder_v05_y1=(_m_Gradient_Coder_v05_y1+1)){
						BBINT bbt_164=(_m_Gradient_Coder_v05_gridx-1);
						for(_m_Gradient_Coder_v05_x1=0;(_m_Gradient_Coder_v05_x1<=bbt_164);_m_Gradient_Coder_v05_x1=(_m_Gradient_Coder_v05_x1+1)){
							BBUINT* bbt_165=((BBARRAY)_m_Gradient_Coder_v05_valuey3)->scales + 1;
							BBFLOAT bbt_ry=((BBFLOAT)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey3,1))[(*(bbt_165)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])-16));
							BBUINT* bbt_166=((BBARRAY)_m_Gradient_Coder_v05_valueu3)->scales + 1;
							BBFLOAT bbt_ru=((BBFLOAT)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu3,1))[(*(bbt_166)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])-128));
							BBUINT* bbt_167=((BBARRAY)_m_Gradient_Coder_v05_valuev3)->scales + 1;
							BBFLOAT bbt_rv=((BBFLOAT)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev3,1))[(*(bbt_167)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])-128));
							BBUINT* bbt_168=((BBARRAY)_m_Gradient_Coder_v05_valuered2)->scales + 1;
							((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuered2,1))[(*(bbt_168)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)_m_Gradient_Coder_v05_Clamp255((1.164f*bbt_ry)+(1.596f*bbt_rv)));
							BBUINT* bbt_169=((BBARRAY)_m_Gradient_Coder_v05_valuegreen2)->scales + 1;
							((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuegreen2,1))[(*(bbt_169)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)_m_Gradient_Coder_v05_Clamp255(((1.164f*bbt_ry)-(0.392f*bbt_ru))-(0.813f*bbt_rv)));
							BBUINT* bbt_170=((BBARRAY)_m_Gradient_Coder_v05_valueblue2)->scales + 1;
							((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueblue2,1))[(*(bbt_170)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)_m_Gradient_Coder_v05_Clamp255((1.164f*bbt_ry)+(2.017f*bbt_ru)));
							BBUINT* bbt_171=((BBARRAY)_m_Gradient_Coder_v05_valuered2)->scales + 1;
							BBUINT* bbt_172=((BBARRAY)_m_Gradient_Coder_v05_valuegreen2)->scales + 1;
							BBUINT* bbt_173=((BBARRAY)_m_Gradient_Coder_v05_valueblue2)->scales + 1;
							brl_max2d_SetColor(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuered2,1))[(*(bbt_171)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]),((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuegreen2,1))[(*(bbt_172)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]),((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueblue2,1))[(*(bbt_173)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]));
							brl_max2d_Plot(((BBFLOAT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)),((BBFLOAT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1)));
						}
					}
					_m_Gradient_Coder_v05_f=(_m_Gradient_Coder_v05_f+(_m_Gradient_Coder_v05_gridx-1));
				}
				brl_graphics_Flip(-1);
				BBINT bbt_174=((_m_Gradient_Coder_v05_largura-1)-_m_Gradient_Coder_v05_gridx);
				for(_m_Gradient_Coder_v05_f=0;(_m_Gradient_Coder_v05_f<=bbt_174);_m_Gradient_Coder_v05_f=(_m_Gradient_Coder_v05_f+1)){
					BBINT bbt_175=(_m_Gradient_Coder_v05_gridy-1);
					for(_m_Gradient_Coder_v05_y1=0;(_m_Gradient_Coder_v05_y1<=bbt_175);_m_Gradient_Coder_v05_y1=(_m_Gradient_Coder_v05_y1+1)){
						BBINT bbt_176=(_m_Gradient_Coder_v05_gridx-1);
						for(_m_Gradient_Coder_v05_x1=0;(_m_Gradient_Coder_v05_x1<=bbt_176);_m_Gradient_Coder_v05_x1=(_m_Gradient_Coder_v05_x1+1)){
							BBUINT* bbt_177=((BBARRAY)_m_Gradient_Coder_v05_valuey3)->scales + 1;
							BBFLOAT bbt_ry2=((BBFLOAT)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey3,1))[(*(bbt_177)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])-16));
							BBUINT* bbt_178=((BBARRAY)_m_Gradient_Coder_v05_valueu3)->scales + 1;
							BBFLOAT bbt_ru2=((BBFLOAT)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu3,1))[(*(bbt_178)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])-128));
							BBUINT* bbt_179=((BBARRAY)_m_Gradient_Coder_v05_valuev3)->scales + 1;
							BBFLOAT bbt_rv2=((BBFLOAT)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev3,1))[(*(bbt_179)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))])-128));
							BBUINT* bbt_180=((BBARRAY)_m_Gradient_Coder_v05_valuered2)->scales + 1;
							((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuered2,1))[(*(bbt_180)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)_m_Gradient_Coder_v05_Clamp255((1.164f*bbt_ry2)+(1.596f*bbt_rv2)));
							BBUINT* bbt_181=((BBARRAY)_m_Gradient_Coder_v05_valuegreen2)->scales + 1;
							((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuegreen2,1))[(*(bbt_181)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)_m_Gradient_Coder_v05_Clamp255(((1.164f*bbt_ry2)-(0.392f*bbt_ru2))-(0.813f*bbt_rv2)));
							BBUINT* bbt_182=((BBARRAY)_m_Gradient_Coder_v05_valueblue2)->scales + 1;
							((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueblue2,1))[(*(bbt_182)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]=((BBBYTE)_m_Gradient_Coder_v05_Clamp255((1.164f*bbt_ry2)+(2.017f*bbt_ru2)));
							BBUINT* bbt_183=((BBARRAY)_m_Gradient_Coder_v05_valuered2)->scales + 1;
							BBUINT* bbt_184=((BBARRAY)_m_Gradient_Coder_v05_valuegreen2)->scales + 1;
							BBUINT* bbt_185=((BBARRAY)_m_Gradient_Coder_v05_valueblue2)->scales + 1;
							brl_max2d_SetColor(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuered2,1))[(*(bbt_183)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]),((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuegreen2,1))[(*(bbt_184)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]),((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueblue2,1))[(*(bbt_185)) * ((BBUINT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)) + ((BBUINT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1))]));
							brl_max2d_Plot(((BBFLOAT)(_m_Gradient_Coder_v05_f+_m_Gradient_Coder_v05_x1)),((BBFLOAT)(_m_Gradient_Coder_v05_y+_m_Gradient_Coder_v05_y1)));
						}
					}
					_m_Gradient_Coder_v05_f=(_m_Gradient_Coder_v05_f+(_m_Gradient_Coder_v05_gridx-1));
				}
				brl_graphics_Flip(-1);
				_m_Gradient_Coder_v05_actualtime=((BBDOUBLE)bbMilliSecs());
				_m_Gradient_Coder_v05_buffertime=(_m_Gradient_Coder_v05_actualtime-_m_Gradient_Coder_v05_begintime2);
				_m_Gradient_Coder_v05_begintime2=_m_Gradient_Coder_v05_actualtime;
				_m_Gradient_Coder_v05_timeleft=((BBDOUBLE)(((BBINT)(_m_Gradient_Coder_v05_buffertime*((BBDOUBLE)((_m_Gradient_Coder_v05_altura-_m_Gradient_Coder_v05_y)/_m_Gradient_Coder_v05_gridy))))/10));
				_m_Gradient_Coder_v05_secondsToStringDaysAndHours((BBINT)_m_Gradient_Coder_v05_timeleft);
				if((((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))<128.000000f) && (((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))>63.0000000f)){
					_m_Gradient_Coder_v05_multiply=0.875;
				}
				if((((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))<63.0000000f) && (((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))>32.0000000f)){
					_m_Gradient_Coder_v05_multiply=0.75;
				}
				if((((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))<32.0000000f) && (((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))>16.0000000f)){
					_m_Gradient_Coder_v05_multiply=0.5;
				}
				if((((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))<16.0000000f) && (((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))>8.00000000f)){
					_m_Gradient_Coder_v05_multiply=0.375;
				}
				if((((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))<8.00000000f) && (((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))>4.00000000f)){
					_m_Gradient_Coder_v05_multiply=0.25;
				}
				if(((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))<4.00000000f){
					_m_Gradient_Coder_v05_multiply=0.125;
				}
				_m_Gradient_Coder_v05_size=((BBDOUBLE)(((BBFLOAT)(_m_Gradient_Coder_v05_multiply/2.0000000000000000))*((BBFLOAT)((_m_Gradient_Coder_v05_altura*_m_Gradient_Coder_v05_largura)*3))));
				bbWriteStdout(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(bbStringConcat(((BBString*)&_s22),bbStringFromInt(_m_Gradient_Coder_v05_x)),((BBString*)&_s23)),bbStringFromInt(_m_Gradient_Coder_v05_y)),((BBString*)&_s24)),bbStringFromInt(_m_Gradient_Coder_v05_gridx)),((BBString*)&_s25)),bbStringFromFloat((BBFLOAT)(_m_Gradient_Coder_v05_maxinsertfinal/((BBDOUBLE)(((_m_Gradient_Coder_v05_gridx*_m_Gradient_Coder_v05_gridy)*3)*_m_Gradient_Coder_v05_trys))))),((BBString*)&_s26)),_m_Gradient_Coder_v05_stringElapsedTime),((BBString*)&_s27)),bbStringFromInt((BBINT)_m_Gradient_Coder_v05_size)),((BBString*)&_s28)),((BBString*)&_s34)));
				_m_Gradient_Coder_v05_x=(_m_Gradient_Coder_v05_x+(_m_Gradient_Coder_v05_gridx-1));
			}
			_m_Gradient_Coder_v05_y=(_m_Gradient_Coder_v05_y+(_m_Gradient_Coder_v05_gridy-1));
		}
		brl_filesystem_CloseFile((struct brl_stream_TStream_obj*)_m_Gradient_Coder_v05_file001);
		_m_Gradient_Coder_v05_elapsedtime=((BBFLOAT)bbMilliSecs());
		_m_Gradient_Coder_v05_timespend=((BBINT)(_m_Gradient_Coder_v05_elapsedtime-_m_Gradient_Coder_v05_begintime));
		_m_Gradient_Coder_v05_secondsToStringDaysAndHours(_m_Gradient_Coder_v05_timespend/1000);
		brl_standardio_Print(bbStringConcat(((BBString*)&_s32),_m_Gradient_Coder_v05_stringElapsedTime));
		BBINT bbt_186=(_m_Gradient_Coder_v05_altura-1);
		for(_m_Gradient_Coder_v05_y=0;(_m_Gradient_Coder_v05_y<=bbt_186);_m_Gradient_Coder_v05_y=(_m_Gradient_Coder_v05_y+1)){
			BBINT bbt_187=(_m_Gradient_Coder_v05_largura-1);
			for(_m_Gradient_Coder_v05_x=0;(_m_Gradient_Coder_v05_x<=bbt_187);_m_Gradient_Coder_v05_x=(_m_Gradient_Coder_v05_x+1)){
				BBUINT* bbt_188=((BBARRAY)_m_Gradient_Coder_v05_valuey3)->scales + 1;
				BBFLOAT bbt_ry3=((BBFLOAT)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuey3,1))[(*(bbt_188)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])-16));
				BBUINT* bbt_189=((BBARRAY)_m_Gradient_Coder_v05_valueu3)->scales + 1;
				BBFLOAT bbt_ru3=((BBFLOAT)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueu3,1))[(*(bbt_189)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])-128));
				BBUINT* bbt_190=((BBARRAY)_m_Gradient_Coder_v05_valuev3)->scales + 1;
				BBFLOAT bbt_rv3=((BBFLOAT)(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuev3,1))[(*(bbt_190)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])-128));
				BBUINT* bbt_191=((BBARRAY)_m_Gradient_Coder_v05_valuered2)->scales + 1;
				((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuered2,1))[(*(bbt_191)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=((BBBYTE)_m_Gradient_Coder_v05_Clamp255((1.164f*bbt_ry3)+(1.596f*bbt_rv3)));
				BBUINT* bbt_192=((BBARRAY)_m_Gradient_Coder_v05_valuegreen2)->scales + 1;
				((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuegreen2,1))[(*(bbt_192)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=((BBBYTE)_m_Gradient_Coder_v05_Clamp255(((1.164f*bbt_ry3)-(0.392f*bbt_ru3))-(0.813f*bbt_rv3)));
				BBUINT* bbt_193=((BBARRAY)_m_Gradient_Coder_v05_valueblue2)->scales + 1;
				((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueblue2,1))[(*(bbt_193)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]=((BBBYTE)_m_Gradient_Coder_v05_Clamp255((1.164f*bbt_ry3)+(2.017f*bbt_ru3)));
			}
		}
		struct brl_pixmap_TPixmap_obj* bbt_pix=(struct brl_pixmap_TPixmap_obj*)brl_pixmap_CreatePixmap(_m_Gradient_Coder_v05_largura,_m_Gradient_Coder_v05_altura,4,4);
		BBINT bbt_color=0;
		BBINT bbt_194=(_m_Gradient_Coder_v05_altura-1);
		for(_m_Gradient_Coder_v05_y=0;(_m_Gradient_Coder_v05_y<=bbt_194);_m_Gradient_Coder_v05_y=(_m_Gradient_Coder_v05_y+1)){
			BBINT bbt_195=(_m_Gradient_Coder_v05_largura-1);
			for(_m_Gradient_Coder_v05_x=0;(_m_Gradient_Coder_v05_x<=bbt_195);_m_Gradient_Coder_v05_x=(_m_Gradient_Coder_v05_x+1)){
				BBUINT* bbt_196=((BBARRAY)_m_Gradient_Coder_v05_valuered2)->scales + 1;
				BBUINT* bbt_197=((BBARRAY)_m_Gradient_Coder_v05_valuegreen2)->scales + 1;
				BBUINT* bbt_198=((BBARRAY)_m_Gradient_Coder_v05_valueblue2)->scales + 1;
				bbt_color=(((((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuered2,1))[(*(bbt_196)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])<<16)+(((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valuegreen2,1))[(*(bbt_197)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)])<<8))+((BBINT)((BBBYTE*)BBARRAYDATA(_m_Gradient_Coder_v05_valueblue2,1))[(*(bbt_198)) * ((BBUINT)_m_Gradient_Coder_v05_x) + ((BBUINT)_m_Gradient_Coder_v05_y)]));
				brl_pixmap_WritePixel((struct brl_pixmap_TPixmap_obj*)bbt_pix,_m_Gradient_Coder_v05_x,_m_Gradient_Coder_v05_y,bbt_color);
			}
		}
		image_png_SavePixmapPNG((struct brl_pixmap_TPixmap_obj*)bbt_pix,(BBOBJECT)_m_Gradient_Coder_v05_filestringoutdatpng,5);
		brl_standardio_Print((BBString*)&_s33);
		return 0;
	}
	return 0;
}